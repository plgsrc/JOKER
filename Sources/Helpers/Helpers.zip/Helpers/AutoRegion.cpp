#include "Helpers/AutoRegion.hpp"

namespace	CTRPluginFramework
{
	// Global to keep the current region
	Region	g_region = JAP;

	AutoRegion::AutoRegion( u32 jap, u32 usa, u32 eur ):
	Jap( usa ), Usa( usa ), Eur( eur )
	{

	}

	u32 AutoRegion::operator()( void ) const
	{
		if( g_region == USA ) return( Usa );
		else if( g_region == EUR ) return( Eur );
		return( Jap );
	}
}
